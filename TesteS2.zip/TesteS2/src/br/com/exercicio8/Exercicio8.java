package br.com.exercicio8;

public class Exercicio8 {

    public static int gerarValorC(Integer valorA, Integer valorB) {

        char[] listA = valorA.toString().toCharArray();
        char[] listB = valorB.toString().toCharArray();
        int maiorIndex = listA.length > listB.length ? listA.length : listB.length;

        String stringC = "";

        for (int x = 0; x < maiorIndex; x++) {
            if (listA.length > x) {
                stringC += String.valueOf(listA[x]);
            }
            if (listB.length > x) {
                stringC += String.valueOf(listB[x]);
            }
        }

        Integer valorC = Integer.valueOf(stringC);

        return valorC > 1000000 ? -1 : valorC;
    }
}

package br.com.exercicio9;

public class BinaryTree {

    public No raiz;

    int somaDosNosSubsequentes = 0;

    public void inserir(int valor) {
        No no = new No(valor);

        if (raiz == null) {
            raiz = no;
        } else {
            No noAux = raiz;
            No pai;

            while (true) {
                pai = noAux;

                if (valor < noAux.valor) {
                    noAux = noAux.filhoEsquerda;

                    if (noAux == null) {
                        pai.filhoEsquerda = no;
                        return;
                    }
                } else {
                    noAux = noAux.filhoDireita;

                    if (noAux == null) {
                        pai.filhoDireita = no;
                        return;
                    }
                }
            }
        }
    }

    public int somaNosSubsequentes(No no) {
        if (no == null) {
            return 0;
        }

        if (no == raiz) {
            somaDosNosSubsequentes = somaNosSubsequentes(no.filhoEsquerda)
                    + somaNosSubsequentes(no.filhoDireita);
        } else {
            somaDosNosSubsequentes = somaNosSubsequentes(no.filhoEsquerda)
                    + somaNosSubsequentes(no.filhoDireita)
                    + no.valor;
        }

        return somaDosNosSubsequentes;

    }
}

class No {
    int valor;
    No filhoEsquerda;
    No filhoDireita;

    No(int valor) {
        this.valor = valor;
    }
}

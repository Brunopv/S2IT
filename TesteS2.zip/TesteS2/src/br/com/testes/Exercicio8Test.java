package br.com.testes;

import br.com.exercicio8.Exercicio8;
import org.junit.Test;

import static org.junit.Assert.*;

public class Exercicio8Test {

    private static final String  PRIMEIRO_NUMERO_DE_A =  "7";
    private static final String  PRIMEIRO_NUMERO_DE_B =  "6";
    private static final String  SEGUNDO_NUMERO_DE_A =  "1";
    private static final String  SEGUNDO_NUMERO_DE_B =  "2";
    private static final String  RESTANTE_INTEIRO_MAIOR_VALOR =  "25";

    @Test
    public void oPrimeiroNumeroDeCePrimeiroNumeroDeA() {

        assertEquals(PRIMEIRO_NUMERO_DE_A, getPrimeiroNumeroDeC());
    }

    @Test
    public void oSegundoNumeroDeCePrimeiroNumeroDeB() {

        assertEquals(PRIMEIRO_NUMERO_DE_B, getSegundoNumeroDeC());
    }

    @Test
    public void oTerceiroNumeroDeCeSegundoNumeroDeA() {

        assertEquals(SEGUNDO_NUMERO_DE_A, getTerceiroNumeroDeC());
    }

    @Test
    public void oQuartoNumeroDeCeSegundoNumeroDeB() {

        assertEquals(SEGUNDO_NUMERO_DE_B, getQuartoNumeroDeC());
    }

    @Test
    public void casoAeBTamanhosDiferentesCompletarCComRestanteInteiroMaior() {
        int valorC = Exercicio8.gerarValorC(52, 1025);
        assertEquals(512025, valorC);
        assertEquals(RESTANTE_INTEIRO_MAIOR_VALOR, String.valueOf(valorC).substring(4,6));
    }

    @Test
    public void testCalculoResultadoMaiorQue1000000() {
        int valorC = Exercicio8.gerarValorC(10256, 512);
        assertEquals(-1, valorC);
    }

    private String getPrimeiroNumeroDeC() {
        int valorC = Exercicio8.gerarValorC(71, 62);
        return String.valueOf(valorC).substring(0,1);
    }

    private String getSegundoNumeroDeC() {
        int valorC = Exercicio8.gerarValorC(71, 62);
        return String.valueOf(valorC).substring(1, 2);
    }

    private String getTerceiroNumeroDeC() {
        int valorC = Exercicio8.gerarValorC(71, 62);
        return String.valueOf(valorC).substring(2,3);
    }

    private String getQuartoNumeroDeC() {
        int valorC = Exercicio8.gerarValorC(71, 62);
        return String.valueOf(valorC).substring(3,4);
    }
}
package br.com.testes;

import br.com.exercicio9.BinaryTree;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

//TESTE Referente ao Exercicio 9
public class BinaryTreeTest {

    @Test
    public void inserirNoECalculaSomaDosNosSubsequentes() {
        BinaryTree binaryTree = getBinaryTree();
        assertEquals("Não Retorno valor esperado",280, binaryTree.somaNosSubsequentes(binaryTree.raiz));
    }

    private BinaryTree getBinaryTree() {
        BinaryTree binaryTree = new BinaryTree();
        binaryTree.inserir(20);
        binaryTree.inserir(30);
        binaryTree.inserir(20);
        binaryTree.inserir(15);
        binaryTree.inserir(30);
        binaryTree.inserir(40);
        binaryTree.inserir(45);
        binaryTree.inserir(100);

        return binaryTree;
    }

}